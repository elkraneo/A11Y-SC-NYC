import Foundation

enum Destination {
  case onboarding
  case main
}
